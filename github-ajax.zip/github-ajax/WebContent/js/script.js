$(document).ready(function() {
	console.log("jQuery is loaded!");
	
	$.ajax({
		
		url: "https://api.github.com/users"
		
	}).then(function(data) {
		console.log(data);
	    var a="<h1>Source = my1.html</h1>";
		$("#content").append(a);
		concole.log(a);


		var info = "<table style=width:100%>";
		/*info =+ "<tr style=width:100%>";*/
		info += "<th>" + "Login name" +"</th>";
		info += "<th>" + "Type" +  "</th>";
		info += "<th>" + "ID" +  "</th>";
		info += "<th>" + "Avatar" +  "</th>";
		info += "<th>" + "Followers" +  "</th>";
		info += "<th>" + "Following" +  "</th>";
		/*info += "</tr>";*/
		var i;
		for(i=0;i<data.length;i++){

			info+="<tr>"
			info+="<td>" + data[i].login+"</td>";
			info+="<td>" + data[i].type+"</td>";
			info+="<td>" + data[i].id+"</td>";
			info+="<td>" +"<a href=/>"+"</td>";
			$.ajax({
				
				url: data[i].followers_url
				
			}).then(function(data1) {
				console.log(data1);
			info+="<td>" + data1.length+"</td>";
			$("#content").append(info);

			})
			info+="<td>" + data[i].following_url+"</td>";
			info+="</tr>";

		}
/*		info += "Type " + data[0].type + "<br/>";
*//*		info += "MAX: " + data.main.temp_max + "<br/>";
*/		info += "</table>";
		
		$("#content").append(info);
		
		
	})


})