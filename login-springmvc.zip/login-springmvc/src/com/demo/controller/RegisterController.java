package com.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;


@Controller
public class RegisterController {
	
	
	@RequestMapping("Register")
	public ModelAndView Register() {
		String message="Please enter the following details to Register";
		return new ModelAndView("Register","mymessage",message);
	}

}
