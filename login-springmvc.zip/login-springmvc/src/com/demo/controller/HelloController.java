package com.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HelloController {
	
	@RequestMapping("sayhello")
	public ModelAndView sayHi() {
		String message="Welcome to Spring MVC and Topics!";
		
		
		//Name of view page
		//Param name of the data returning to View
		//Param value representing the data which is sent to View
		return new ModelAndView("hello","mymessage",message);
		
	}
}
